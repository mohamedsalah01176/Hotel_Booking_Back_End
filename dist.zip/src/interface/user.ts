export interface IUserBody{
  name:string,
  phone:string,
  email:string,
  password:string,
  role:'user' | 'host' | "manager",
  birthDate:Date,
  _id:string,
  image:string,
  phoneVerfy:boolean,
  createdAt:Date
}
export interface IUpdateBody{
  name?:string,
  phone?:string,
  email?:string,
  oldPassword?:string,
  newPassword?:string,
  password?:string;
  birthDate?:Date,
  _id?:string,
  image?:string,
  phoneVerfy?:boolean,
}
export interface ILoginUser{
  emailOrPhone:string, 
  password:string
}

export interface IUserPayload {
  _id: string;
  role: "manager" | "host" | "user";
  email: string;
  image?:string,
  name?: string;
  phone?: string;
  createdAt:Date;
  phoneVerfy:boolean;
}